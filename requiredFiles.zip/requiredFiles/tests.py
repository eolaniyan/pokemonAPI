from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase


class AccountTests(APITestCase):
    def test_success_response(self):
        """
        Ensure we get 200 ok status code.
        """
        url = reverse('pokemon_api', kwargs={'name': 'charizard'})
        response = self.client.get(url, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
