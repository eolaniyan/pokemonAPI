from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
import requests


@api_view(['GET'])
def pokemon_api(request, name):
    """
    List all the abilities of charizard.
    """

    pokeapi_url = f"https://pokeapi.co/api/v2/pokemon/{name}"
    poke_response = requests.get(pokeapi_url)
    abilities_urls = []
    json_response = poke_response.json()
    for i in json_response['abilities']:
        abilities_urls.append(i)
    ability_strings = []
    for i in abilities_urls:
        ability = requests.get(i['ability']['url'])
        for i in ability.json()['effect_entries']:
            if i['language']['name'] == 'en':
                ability_strings.append(i['effect'])
    data = {'name': name, 'description': ','.join(ability_strings)}
    return Response(data)
